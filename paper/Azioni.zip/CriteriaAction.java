/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiagentcontroller.actions;

import burlap.oomdp.core.TransitionProbability;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import burlap.oomdp.stochasticgames.JointAction;
import burlap.oomdp.stochasticgames.SGDomain;
import burlap.oomdp.stochasticgames.agentactions.GroundedSGAgentAction;
import burlap.oomdp.stochasticgames.agentactions.SimpleSGAgentAction;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import javax.el.ELProcessor;
import static multiagentcontroller.Controller.AGENTCLASS_ATTACKER;
import static multiagentcontroller.Controller.AGENTCLASS_IRS;
import static multiagentcontroller.Controller.ATTACTIVE;
import static multiagentcontroller.Controller.ATTALERTED;
import static multiagentcontroller.Controller.ATTBACKUP;
import static multiagentcontroller.Controller.ATTBLOCKEDIPS;
import static multiagentcontroller.Controller.ATTEVERQUARANTINED;
import static multiagentcontroller.Controller.ATTEVERSHUTDOWN;
import static multiagentcontroller.Controller.ATTFIREWALL;
import static multiagentcontroller.Controller.ATTFLOWLIMITIPS;
import static multiagentcontroller.Controller.ATTHONEYPOTIPS;
import static multiagentcontroller.Controller.ATTLOGVERB;
import static multiagentcontroller.Controller.ATTMANUAL;
import static multiagentcontroller.Controller.ATTNEXTACTION;
import static multiagentcontroller.Controller.ATTPDISTCCD;
import static multiagentcontroller.Controller.ATTPIRCD;
import static multiagentcontroller.Controller.ATTPPHPCGI;
import static multiagentcontroller.Controller.ATTPRMI;
import static multiagentcontroller.Controller.ATTPSCAN;
import static multiagentcontroller.Controller.ATTPSMBD;
import static multiagentcontroller.Controller.ATTPVSFTPD;
import static multiagentcontroller.Controller.ATTQUARANTINED;
import static multiagentcontroller.Controller.ATTREBOOTED;
import static multiagentcontroller.Controller.ATTSOFTWARE;
import static multiagentcontroller.Controller.ATTTIMER;
import static multiagentcontroller.Controller.T1;
import static multiagentcontroller.Controller.T2;

/**
 *
 * @author stefano
 */
public abstract class CriteriaAction extends SimpleSGAgentAction {

    protected double cost;
    protected double responseTime;
    protected double impact;
    private static final String ATTCOST = "Cost";
    private static final String ATTRESPTIME = "ResponseTime";
    private static final String ATTIMPACT = "Impact";

    protected double sPscan;
    protected double sPvsftpd;
    protected double sPsmbd;
    protected double sPphpcgid;
    protected double sPircd;
    protected double sPdistccd;
    protected double sPrmi;

    protected String sAttackerIp;

    protected boolean sFirewall;
    protected String sBlockedIps;
    protected String sFlolimitIps;
    protected String sHoneypotIps;
    protected int sReconfCounter;
    protected int sLogVerb;
    protected boolean sActive;
    protected boolean sQuarantined;
    protected boolean sRebooted;
    protected boolean sAlerted;
    protected boolean sBackup;
    protected boolean sUpdated;
    protected boolean sManual;
    protected boolean sEverQuarantined;
    protected boolean sEverShutDown;
    protected double sIrsTimer;
    protected double sAttThreshold;
    protected double sAttPvsftpd;

    private String precondition;
    private static final String ATTPRECOND = "Precondition";
    private String name;

//    protected Reward reward = null;
    protected void getStateAttributes(State s) {
        ObjectInstance irsAgent = s.getFirstObjectOfClass(AGENTCLASS_IRS);
        ObjectInstance attAgent = s.getFirstObjectOfClass(AGENTCLASS_ATTACKER);
        

        sPscan = irsAgent.getRealValForAttribute(ATTPSCAN);
        sPvsftpd = irsAgent.getRealValForAttribute(ATTPVSFTPD);
        sPsmbd = irsAgent.getRealValForAttribute(ATTPSMBD);
        sPphpcgid = irsAgent.getRealValForAttribute(ATTPPHPCGI);
        sPircd = irsAgent.getRealValForAttribute(ATTPIRCD);
        sPdistccd = irsAgent.getRealValForAttribute(ATTPDISTCCD);
        sPrmi = irsAgent.getRealValForAttribute(ATTPRMI);

//        sAttackerIp = agent.getStringValForAttribute(ATTATTACKERIP);

        sFirewall = irsAgent.getBooleanValForAttribute(ATTFIREWALL);
        sBlockedIps = irsAgent.getStringValForAttribute(ATTBLOCKEDIPS);
        sFlolimitIps = irsAgent.getStringValForAttribute(ATTFLOWLIMITIPS);
        sHoneypotIps = irsAgent.getStringValForAttribute(ATTHONEYPOTIPS);
        sLogVerb = irsAgent.getIntValForAttribute(ATTLOGVERB);
        sActive = irsAgent.getBooleanValForAttribute(ATTACTIVE);
        sQuarantined = irsAgent.getBooleanValForAttribute(ATTQUARANTINED);
        sRebooted = irsAgent.getBooleanValForAttribute(ATTREBOOTED);
        sAlerted = irsAgent.getBooleanValForAttribute(ATTALERTED);
        sBackup = irsAgent.getBooleanValForAttribute(ATTBACKUP);
        sUpdated = irsAgent.getBooleanValForAttribute(ATTSOFTWARE);
        sManual = irsAgent.getBooleanValForAttribute(ATTMANUAL);
        sEverQuarantined = irsAgent.getBooleanValForAttribute(ATTEVERQUARANTINED);
        sEverShutDown = irsAgent.getBooleanValForAttribute(ATTEVERSHUTDOWN);
        sIrsTimer = irsAgent.getRealValForAttribute(ATTTIMER);
        sAttThreshold = attAgent.getRealValForAttribute(ATTNEXTACTION);
        sAttPvsftpd = attAgent.getRealValForAttribute(ATTPVSFTPD);
    }

//    protected void printDebugInfo(ObjectInstance agent) {
//        System.out.println("Executing action: " + super.getName());
//        System.out.println(agent.getObjectDescription());
//    }
    @Override
    public boolean applicableInState(State s, GroundedSGAgentAction gsa) {
        getStateAttributes(s);
        ELProcessor elprocessor = new ELProcessor();
        elprocessor.setValue("pScan", sPscan);
        elprocessor.setValue("pVsftpd", sPvsftpd);
        elprocessor.setValue("pSmbd", sPsmbd);
        elprocessor.setValue("pPhpcgid", sPphpcgid);
        elprocessor.setValue("pIrcd", sPircd);
        elprocessor.setValue("pDistccd", sPdistccd);
        elprocessor.setValue("pRmi", sPrmi);

        elprocessor.setValue("firewall", sFirewall);
        elprocessor.setValue("blockedIps", sBlockedIps);
        elprocessor.setValue("flowlimitIps", sFlolimitIps);
        elprocessor.setValue("honeypotIps", sHoneypotIps);
        elprocessor.setValue("reconfCounter", sReconfCounter);
        elprocessor.setValue("logVerb", sLogVerb);
        elprocessor.setValue("active", sActive);
        elprocessor.setValue("quarantined", sQuarantined);
        elprocessor.setValue("rebooted", sRebooted);
        elprocessor.setValue("alerted", sAlerted);
        elprocessor.setValue("backup", sBackup);
        elprocessor.setValue("softwareUpToDate", sUpdated);
        elprocessor.setValue("manuallySolved", sManual);
        elprocessor.setValue("everQuarantined", sEverQuarantined);
        elprocessor.setValue("everShutDown", sEverShutDown);
        elprocessor.setValue("irsTimer", sIrsTimer);
        elprocessor.setValue("nextActionTimer", sAttThreshold);
        elprocessor.setValue("attPvsftpd", sAttPvsftpd);
        elprocessor.setValue("T1", T1);
        elprocessor.setValue("T2", T2);

        Object eval = elprocessor.eval(precondition);
        boolean ret = Boolean.valueOf(eval.toString());
        return ret;
    }
    
    protected abstract State doAction(State s);
    protected abstract List<TransitionProbability> transitionProbsFor(State s);

    public CriteriaAction(SGDomain domain, String name) throws FileNotFoundException, IOException {
        super(domain, name);
        FileInputStream fis = new FileInputStream("config/" + name + ".properties");
        Properties p = new Properties();
        p.load(fis);
        cost = Double.valueOf(p.getProperty(ATTCOST));
        responseTime = Double.valueOf(p.getProperty(ATTRESPTIME));
        impact = Double.valueOf(p.getProperty(ATTIMPACT));
        precondition = p.getProperty(ATTPRECOND);
        fis.close();
        this.name = name;
//        System.out.println("Action: " + name);
//        System.out.println("Response Time: " + responseTime);
//        System.out.println("Cost: " + cost);
//        System.out.println("Impact: " + impact);
//        System.out.println("Precondition: " + precondition);
    }

    public double getCost() {
        return cost;
    }

    public double getResponseTime() {
        return responseTime;
    }

    public double getImpact() {
        return impact;
    }
    
    

//    public void setReward(Reward r) {
//        this.reward = r;
//    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
