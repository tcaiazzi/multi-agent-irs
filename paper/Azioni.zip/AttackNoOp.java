/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiagentcontroller.actions;

import burlap.oomdp.core.TransitionProbability;
import burlap.oomdp.core.states.State;
import burlap.oomdp.stochasticgames.SGDomain;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author stefano
 */
public class AttackNoOp extends CriteriaAction {

    public AttackNoOp(SGDomain domain, String name) throws IOException {
        super(domain, name);

    }

    @Override
    protected State doAction(State s) {
        State nextState = s.copy();
        return nextState;
    }

    @Override
    protected List<TransitionProbability> transitionProbsFor(State s) {
        List<TransitionProbability> transitions = new ArrayList<>();
        State nextState = s.copy();
        TransitionProbability t = new TransitionProbability(nextState, 1);
        transitions.add(t);
        return transitions;
    }

}
