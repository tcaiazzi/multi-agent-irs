/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiagentcontroller.actions;

import burlap.oomdp.core.TransitionProbability;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import burlap.oomdp.stochasticgames.SGDomain;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import static multiagentcontroller.Controller.AGENTCLASS_ATTACKER;
import static multiagentcontroller.Controller.AGENTCLASS_IRS;
import static multiagentcontroller.Controller.ATTACTIVE;
import static multiagentcontroller.Controller.ATTMANUAL;
import static multiagentcontroller.Controller.ATTPDISTCCD;
import static multiagentcontroller.Controller.ATTPIRCD;
import static multiagentcontroller.Controller.ATTPPHPCGI;
import static multiagentcontroller.Controller.ATTPRMI;
import static multiagentcontroller.Controller.ATTPSCAN;
import static multiagentcontroller.Controller.ATTPSMBD;
import static multiagentcontroller.Controller.ATTPVSFTPD;
import static multiagentcontroller.Controller.ATTQUARANTINED;
import static multiagentcontroller.Controller.ATTTIMER;

/**
 *
 * @author stefano
 */
public class ManualResolution extends CriteriaAction {

    public ManualResolution(SGDomain domain, String name) throws IOException {
        super(domain, name);
    }

    @Override
    protected State doAction(State s) {
        State nextState = s.copy();
        ObjectInstance irsAgent = nextState.getFirstObjectOfClass(AGENTCLASS_IRS);
        double irsTimer = irsAgent.getRealValForAttribute(ATTTIMER);
        irsTimer += this.getResponseTime();
        //Setting the attributes for the next state
        irsAgent.setValue(ATTPSCAN, 0);
        irsAgent.setValue(ATTPVSFTPD, 0);
        irsAgent.setValue(ATTPSMBD, 0);
        irsAgent.setValue(ATTPPHPCGI, 0);
        irsAgent.setValue(ATTPIRCD, 0);
        irsAgent.setValue(ATTPDISTCCD, 0);
        irsAgent.setValue(ATTPRMI, 0);
        irsAgent.setValue(ATTQUARANTINED, false);
        irsAgent.setValue(ATTACTIVE, true);
        irsAgent.setValue(ATTMANUAL, true);
        irsAgent.setValue(ATTTIMER, irsTimer);
        //return the state we just modified
        return nextState;
    }

    @Override
    protected List<TransitionProbability> transitionProbsFor(State s) {
        List<TransitionProbability> transitions = new ArrayList<>();
        State nextState = s.copy();
        ObjectInstance irsAgent = nextState.getFirstObjectOfClass(AGENTCLASS_IRS);
        double irsTimer = irsAgent.getRealValForAttribute(ATTTIMER);
        irsTimer += this.getResponseTime();
        //Setting the attributes for the next state
        irsAgent.setValue(ATTPSCAN, 0);
        irsAgent.setValue(ATTPVSFTPD, 0);
        irsAgent.setValue(ATTPSMBD, 0);
        irsAgent.setValue(ATTPPHPCGI, 0);
        irsAgent.setValue(ATTPIRCD, 0);
        irsAgent.setValue(ATTPDISTCCD, 0);
        irsAgent.setValue(ATTPRMI, 0);
        irsAgent.setValue(ATTQUARANTINED, false);
        irsAgent.setValue(ATTACTIVE, true);
        irsAgent.setValue(ATTMANUAL, true);
        irsAgent.setValue(ATTTIMER, irsTimer);
        TransitionProbability t = new TransitionProbability(nextState, 1);
        transitions.add(t);
        return transitions;
    }

}
