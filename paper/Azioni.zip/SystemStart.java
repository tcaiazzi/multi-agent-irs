/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiagentcontroller.actions;

import burlap.oomdp.core.TransitionProbability;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import burlap.oomdp.stochasticgames.SGDomain;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import static multiagentcontroller.Controller.AGENTCLASS_ATTACKER;
import static multiagentcontroller.Controller.AGENTCLASS_IRS;
import static multiagentcontroller.Controller.ATTACTIVE;
import static multiagentcontroller.Controller.ATTTIMER;

/**
 *
 * @author stefano
 */
public class SystemStart extends CriteriaAction {

    public SystemStart(SGDomain domain, String name) throws IOException {
        super(domain, name);
    }

    @Override
    protected State doAction(State s) {
        State nextState = s.copy();
        ObjectInstance irsAgent = nextState.getFirstObjectOfClass(AGENTCLASS_IRS);
        double irsTimer = irsAgent.getRealValForAttribute(ATTTIMER);
        irsTimer += this.getResponseTime();

        //Setting the attributes for the next state
        irsAgent.setValue(ATTACTIVE, true);
        irsAgent.setValue(ATTTIMER, irsTimer);

        //return the state we just modified
        return nextState;
    }

    @Override
    protected List<TransitionProbability> transitionProbsFor(State s) {
        List<TransitionProbability> transitions = new ArrayList<>();
        State nextState = s.copy();
        ObjectInstance irsAgent = nextState.getFirstObjectOfClass(AGENTCLASS_IRS);
        double irsTimer = irsAgent.getRealValForAttribute(ATTTIMER);
        irsTimer += this.getResponseTime();

        //Setting the attributes for the next state
        irsAgent.setValue(ATTACTIVE, true);
        irsAgent.setValue(ATTTIMER, irsTimer);
        TransitionProbability t = new TransitionProbability(nextState, 1);
        transitions.add(t);
        return transitions;
    }

}
