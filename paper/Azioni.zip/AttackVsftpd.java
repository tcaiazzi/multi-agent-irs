/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiagentcontroller.actions;

import burlap.oomdp.core.TransitionProbability;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import burlap.oomdp.stochasticgames.SGDomain;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import multiagentcontroller.Controller;
import static multiagentcontroller.Controller.ATTNEXTACTION;
import static multiagentcontroller.Controller.ATTPVSFTPD;
import static multiagentcontroller.Controller.ATTSOFTWARE;
import static multiagentcontroller.Controller.ATTTIMER;

/**
 *
 * @author stefano
 */
public class AttackVsftpd extends CriteriaAction {

    public AttackVsftpd(SGDomain domain, String name) throws IOException {
        super(domain, name);
    }

    @Override
    protected State doAction(State s) {
        State nextState = s.copy();
        //Setting the attribute as true for the next state
        ObjectInstance attackerAgent = nextState.getFirstObjectOfClass(Controller.AGENTCLASS_ATTACKER);
        ObjectInstance irsAgent = nextState.getFirstObjectOfClass(Controller.AGENTCLASS_IRS);
        if (!irsAgent.getBooleanValForAttribute(ATTSOFTWARE)) {
            irsAgent.setValue(ATTPVSFTPD, 1);
        }

        double nextAction = irsAgent.getRealValForAttribute(ATTTIMER);
//        irsTimer += this.getResponseTime();
        nextAction += this.getResponseTime();
        attackerAgent.setValue(ATTNEXTACTION, nextAction);
        //return the state we just modified
        return nextState;
    }

    @Override
    protected List<TransitionProbability> transitionProbsFor(State s) {
        List<TransitionProbability> transitions = new ArrayList<>();
        State nextState = s.copy();
        ObjectInstance attackerAgent = nextState.getFirstObjectOfClass(Controller.AGENTCLASS_ATTACKER);
        ObjectInstance irsAgent = nextState.getFirstObjectOfClass(Controller.AGENTCLASS_IRS);
        if (!irsAgent.getBooleanValForAttribute(ATTSOFTWARE)) {
            irsAgent.setValue(ATTPVSFTPD, 1);
        }

        double nextAction = irsAgent.getRealValForAttribute(ATTTIMER);
//        irsTimer += this.getResponseTime();
        nextAction += this.getResponseTime();
        attackerAgent.setValue(ATTNEXTACTION, nextAction);
        TransitionProbability t = new TransitionProbability(nextState, 1);
        transitions.add(t);
        return transitions;
    }

}
