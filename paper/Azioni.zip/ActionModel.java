/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiagentcontroller.actions;

import burlap.oomdp.core.TransitionProbability;
import burlap.oomdp.core.objects.ObjectInstance;
import burlap.oomdp.core.states.State;
import burlap.oomdp.stochasticgames.JointAction;
import burlap.oomdp.stochasticgames.JointActionModel;
import burlap.oomdp.stochasticgames.agentactions.GroundedSGAgentAction;
import java.util.ArrayList;
import java.util.List;
import multiagentcontroller.Controller;
import static multiagentcontroller.Controller.AGENTCLASS_IRS;
import static multiagentcontroller.Controller.ATTPVSFTPD;

/**
 *
 * @author stefano
 */
public class ActionModel extends JointActionModel {

    @Override
    public List<TransitionProbability> transitionProbsFor(State s, JointAction ja) {

        GroundedSGAgentAction irsGroundedAction = ja.action(Controller.AGENTTYPE_IRS + "0");
        CriteriaAction action = (CriteriaAction) irsGroundedAction.action;
        List<TransitionProbability> transitions = action.transitionProbsFor(s);
        
        GroundedSGAgentAction attackerGroundedAction = ja.action(Controller.AGENTTYPE_ATTACKER+"0");
        List<TransitionProbability> newTransitions = transitions;
        if (attackerGroundedAction.actionName().equals("attackVsftpdAction") && attackerGroundedAction.applicableInState(s)) {
            newTransitions = new ArrayList<>(transitions.size());
            for (TransitionProbability t:transitions) {
                State nextState = t.s.copy();
                double prob = t.p;
                ObjectInstance irsAgent = nextState.getFirstObjectOfClass(AGENTCLASS_IRS);
                irsAgent.setValue(ATTPVSFTPD, 1);
                TransitionProbability newT = new TransitionProbability(nextState, prob);
                newTransitions.add(newT);
            }
        }
        return newTransitions;

    }

    @Override
    protected State actionHelper(State s, JointAction ja) {

        List<GroundedSGAgentAction> actions = ja.getActionList();
        State nextState = s;
        for (GroundedSGAgentAction a : actions) {
            CriteriaAction action = (CriteriaAction) a.action;
            nextState = action.doAction(nextState);
        }
        return nextState;
    }

}
